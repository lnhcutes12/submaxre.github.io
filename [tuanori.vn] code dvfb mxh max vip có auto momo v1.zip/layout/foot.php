
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © 2021 &amp; Developed by <a href="https://www.facebook.com/DucThanhIT/" target="_blank">DucThanh IT</a> </p>
            </div>
        </div>
        
        <!--**********************************
            START CUSTOM JS BY JZON DEV
        ***********************************-->

        <?= setting('plugin_js'); ?>

        <!--**********************************
            END CUSTOM JS BY JZON DEV
        ***********************************-->
        <a href="/support/create" class="contact text-decoration-none" style="color: white!important;">
            <span style="font-weight: bold; font-size: .83333rem;">
                <i class="far fa-life-ring" style="margin-right: 5px;"></i>
                Gửi Yêu Cầu Hỗ Trợ
            </span>
        </a>

        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->

    <!-- XÂY DỰNG WEBSITE KIẾM TIỀN ONLINE MMO | LIÊN HỆ ZALO 0966142061 | JZONTECH.ASIA -->
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/public/js/app.js?<?= time(); ?>"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/public/js/module.js?<?= time(); ?>"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/jquery.dataTables.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/jquery.nice-select.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/select2.full.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/select2-init.js"></script>
    
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/owl.carousel.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/jzonDev/jzontech/global.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/vendor/bootstrap-datetimepicker/js/moment.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>

    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/dashboard/dashboard-1.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/jzonDev/deznav-init.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/styleSwitcher.js"></script>
    <script src="https://<?= $_SERVER['SERVER_NAME']; ?>/frontend/main/js/jzonDev/jzontech.js"></script>
    <!-- XÂY DỰNG WEBSITE KIẾM TIỀN ONLINE MMO | LIÊN HỆ ZALO 0966142061 | JZONTECH.ASIA -->
</body>
</html>